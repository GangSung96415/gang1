import { TestBed, async } from '@angular/core/testing';
import { CatsComponent } from './cats.component';

/*describe('Component: Cats', () => {
  it('should create an instance', () => {
    let component = new CatsComponent();
    expect(component).toBeTruthy();
  });
});*/
